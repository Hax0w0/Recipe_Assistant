import strawberry
from GraphQL.query import Query

schema = strawberry.Schema(query=Query)
import strawberry

@strawberry.type
class Step_Type:
    number: int
    description: str
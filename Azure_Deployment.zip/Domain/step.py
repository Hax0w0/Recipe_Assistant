class Step:
    number: int
    description: str

    def __init__(self, number: int, description: str):
        
        self.number = number
        self.description = description